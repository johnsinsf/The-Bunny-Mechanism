#ifdef _USEMYSQL
  #include "SBase_mysql.cc"
#endif
#ifdef _USEFILES
  #include "SBase_files.cc"
#endif
