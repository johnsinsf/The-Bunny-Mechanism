#ifdef _USEMYSQL
  #include "SBase_mysql.h"
#endif
#ifdef _USEFILES
  #include "SBase_files.h"
#endif
